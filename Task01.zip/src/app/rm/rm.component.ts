import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rm',
  templateUrl: './rm.component.html',
  styleUrls: ['./rm.component.css']
})
export class RmComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
